package io.github.examenDBR;

import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;

public class PantallaJuego extends Pantalla {

    float stateTime = 0f;

    // TODO: spawn timer si hay enemigos
    // float spawnTimer = 2f;

    // TODO: array de entidades si hay varias
    // Array<MiEntidad> entidades = new Array<>();

    // TODO: personaje si hay uno
    // MiPersonaje personaje;

    public PantallaJuego(Main game) {
        super(game);
        // Reset estado global
        Mundo.puntos = 0;
        Mundo.vidas = 3;
        Mundo.victoria = false;

        // TODO: inicializar entidades
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        stateTime += delta;

        // --- SPAWN por timer ---
        // spawnTimer -= delta;
        // if (spawnTimer <= 0) {
        //     entidades.add(new MiEntidad());
        //     spawnTimer = MathUtils.random(1f, 3f);
        // }

        // --- UPDATE ---
        // personaje.update(delta);
        // for (MiEntidad e : entidades) e.update(delta);

        // --- COLISIONES (recorre al revés para poder eliminar) ---
        // for (int i = entidades.size - 1; i >= 0; i--) {
        //     MiEntidad e = entidades.get(i);
        //     if (e.destruida) { entidades.removeIndex(i); Mundo.puntos++; continue; }
        //     if (e.fuera)     { entidades.removeIndex(i); continue; }
        //     if (personaje.hitbox.overlaps(e.hitbox)) terminarPartida(false);
        // }

        // --- DIBUJAR FORMAS ---
        sr.begin(ShapeRenderer.ShapeType.Filled);
        // TODO: dibujar entidades
        sr.end();

        // DEBUG hitboxes
        if (Mundo.DEBUG) {
            sr.begin(ShapeRenderer.ShapeType.Line);
            sr.setColor(Color.RED);
            // TODO: sr.rect(e.hitbox.x, e.hitbox.y, e.hitbox.width, e.hitbox.height);
            sr.end();
        }

        // --- HUD ---
        batch.begin();
        font.draw(batch, "Tiempo: " + String.format("%.2f", stateTime), 10, Mundo.ALTO + Mundo.TOP_BAR - 10);
        font.draw(batch, "Puntos: " + Mundo.puntos, 200, Mundo.ALTO + Mundo.TOP_BAR - 10);
        batch.end();
    }

    // --- INPUT TECLADO ---
    @Override
    public boolean keyDown(int keycode) {
        switch (keycode) {
            case Input.Keys.UP:    /* TODO */ break;
            case Input.Keys.DOWN:  /* TODO */ break;
            case Input.Keys.LEFT:  /* TODO */ break;
            case Input.Keys.RIGHT: /* TODO */ break;
            case Input.Keys.SPACE: /* TODO */ break;
            case Input.Keys.ESCAPE: game.setScreen(new PantallaInicio(game)); break;
        }
        return true;
    }

    @Override
    public boolean keyUp(int keycode) {
        switch (keycode) {
            case Input.Keys.UP:
            case Input.Keys.DOWN:
                /* TODO: personaje.parar(); */
                break;
        }
        return true;
    }

    // --- INPUT TOUCH ---
    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        Vector3 v3 = new Vector3(screenX, screenY, 0);
        camera.unproject(v3);
        // TODO: comprobar si tocó alguna entidad
        // for (MiEntidad e : entidades) {
        //     if (e.isHit(v3.x, v3.y)) { e.destruida = true; break; }
        // }
        return true;
    }

    // --- FIN DE PARTIDA ---
    private void terminarPartida(boolean victoria) {
        Mundo.victoria = victoria;
        Mundo.tiempoFinal = stateTime;
        Mundo.guardarRecord(stateTime);
        game.setScreen(new PantallaResultado(game));
    }
}
