package io.github.examenDBR;

import com.badlogic.gdx.Input;
import com.badlogic.gdx.utils.ScreenUtils;

public class PantallaResultado extends Pantalla {

    public PantallaResultado(Main game) {
        super(game);
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        batch.begin();

        if (Mundo.victoria) {
            font.draw(batch, "VICTORIA!", Mundo.MITAD_ANCHO - 40, Mundo.MITAD_ALTO + 60);
        } else {
            font.draw(batch, "GAME OVER", Mundo.MITAD_ANCHO - 40, Mundo.MITAD_ALTO + 60);
        }

        font.draw(batch, "Tiempo: " + String.format("%.2f", Mundo.tiempoFinal) + "s", Mundo.MITAD_ANCHO - 40, Mundo.MITAD_ALTO + 20);
        font.draw(batch, "Puntos: " + Mundo.puntos, Mundo.MITAD_ANCHO - 40, Mundo.MITAD_ALTO - 10);
        font.draw(batch, "Record: " + String.format("%.2f", Mundo.getRecord()) + "s", Mundo.MITAD_ANCHO - 40, Mundo.MITAD_ALTO - 40);
        font.draw(batch, "ESPACIO para volver", 20, 25);

        batch.end();
    }

    @Override
    public boolean keyDown(int keycode) {
        if (keycode == Input.Keys.SPACE) {
            game.setScreen(new PantallaInicio(game));
        }
        return true;
    }
}
