package cubes.game;

public class World {

    public static int gameWidth = 640;
    public static int gameHeight = 480;
    public static float halfGameWidth = gameWidth /2;
    public static float halfGameHeight = gameHeight /2;
    public static float topBarHeight = 60f;

}
