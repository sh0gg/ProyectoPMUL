package cubes.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.math.Vector2;


public class PantallaJuego extends Pantalla {

    int numInsectos = 0;
    int numKills = 0;

    String recordString = "";
    String killsString = "";
    Array<Insecto> insectos  = new Array<Insecto>();

    float recordTime = -1f;
    float stateTime = 0;
    boolean hayRecord = false;

    Preferences preferences = Gdx.app.getPreferences("record.prefs");

    public PantallaJuego(Main game, int numInsectos) {
        super(game);
        this.numInsectos = numInsectos;

        cargarRecord();
        crearInsectos(numInsectos);
    }

    private void cargarRecord() {
        recordTime = preferences.getFloat("record"+ numInsectos,0);
        hayRecord = recordTime != 0;
        recordString = hayRecord? String.format("Record: %.2fs",recordTime) : "Record: sin record";
    }

    private void crearInsectos(int numInsectos) {
        float x = Mundo.MITAD_ANCHO_MUNDO - game.mitadTamanoTextura;
        float y = Mundo.MITAD_ALTO_MUNDO - game.mitadTamanoTextura;
        insectos.add(new Insecto(x,y,game.tamanoTextura,50,game.imagenesInsectos));
    }

    private void guardarRecord(float stateTime) {
        preferences.putFloat("record"+ numInsectos, stateTime);
        preferences.flush();
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);

        stateTime += delta;

        drawShapes(delta);
        drawSprites(delta);
    }

    public void drawShapes(float delta){
        sr.begin(ShapeRenderer.ShapeType.Filled);
        sr.setColor(Color.RED);
        for (Vector2 point : game.puntos){
            sr.circle(point.x,point.y,game.mitadTamanoTextura);
        }
        sr.setColor(Color.WHITE);
        sr.line(
            0,
            Mundo.ALTO_MUNDO - Mundo.ALTURA_MENU_SUPERIOR,
            Mundo.ANCHO_MUNDO,
            Mundo.ALTO_MUNDO -Mundo.ALTURA_MENU_SUPERIOR
        );

        sr.end();
    }


    public void drawSprites(float delta){
        batch.begin();

        // 2. Aseguramos que el color de la fuente sea visible (ej. Blanco sobre el fondo gris)
        fuente.setColor(Color.WHITE);
        fuente.draw(
            batch,
            "Tpo: " + stateTime,
            10,
            Mundo.ALTO_MUNDO - 10
        );

        fuente.draw(
            batch,
            "RECORD CON " + numInsectos + " INSECTOS: " + recordTime,
            200,
            Mundo.ALTO_MUNDO - 10
        );

        fuente.draw(
            batch,
            "KILLS: " + killsString,
            500,
            Mundo.ALTO_MUNDO - 10
        );


        for (Insecto insecto : insectos) {
            insecto.update(delta);
            insecto.render(batch);
        }

        batch.end();
    }


    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        // Convert screen coordinates (pixels) to world coordinates (game units)
        Vector3 v3ScreenCoord = new Vector3(screenX, screenY, 0);
        Vector3 v3WorldCoord = camera.unproject(v3ScreenCoord);

        Vector2 v2 = new Vector2(v3WorldCoord.x, v3WorldCoord.y);

        for (Insecto insecto : insectos) {
            //System.out.println(inset);
            if (insecto.isHit(v2)){
                numKills++;


                if(numKills >= numInsectos){
                    // Solo guardamos el punto si es la muerte final
                  //  game.puntos.clear(); // Opcional: limpia marcas de partidas anteriores
                    game.puntos.add(v2);
                    if (hayRecord){
                        if (stateTime < recordTime){
                            guardarRecord(stateTime);
                        }

                    }else{
                        guardarRecord(stateTime);
                    }

                    game.irAPantallaInicio();
                }
                else{
                    insecto.nextInsecto();
                    killsString = "I".repeat(numKills);
                }

                return true;
            }
        }
        return true;
    }

    @Override
    public void resize(int i, int i1) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}


