package cubes.game;

public class Mundo {

    public static int ANCHO_MUNDO = 640;
    public static int ALTO_MUNDO = 480;
    public static float MITAD_ANCHO_MUNDO = ANCHO_MUNDO / 2;
    public static float MITAD_ALTO_MUNDO = ALTO_MUNDO / 2;
    public static float ALTURA_MENU_SUPERIOR = 30;

}
