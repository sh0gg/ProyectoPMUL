package cubes.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

public abstract class Pantalla extends InputAdapter implements Screen {
    protected Main game;
    public OrthographicCamera camera;
    public SpriteBatch batch;
    public ShapeRenderer sr;
    public BitmapFont fuente;
    public GlyphLayout layout;
    public static float topBarY = Mundo.ANCHO_MUNDO + Mundo.ALTURA_MENU_SUPERIOR / 2;

    public Pantalla(Main game) {
        this.game = game;
        batch = game.spriteBatch;
        sr = game.shapeRenderer;
        fuente = game.font;
        layout = game.layout;

        camera = new OrthographicCamera();
        camera.setToOrtho(false, Mundo.ANCHO_MUNDO, Mundo.ALTO_MUNDO + Mundo.ALTURA_MENU_SUPERIOR);

        // Aplicar camara a batch y shapeRenderer
        batch.setProjectionMatrix(camera.combined);
        sr.setProjectionMatrix(camera.combined);

    }

    @Override
    public abstract void render(float delta);

    @Override
    public void show() {
        Gdx.input.setInputProcessor(this);
    }
}
