package com.example.eleccionesannimas;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class ResultadoActivity extends AppCompatActivity {

    TextView tvTotal, l1, v1, l2, v2, l3, v3, l4, v4, labst, vabst;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_resultado);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets sb = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(sb.left, sb.top, sb.right, sb.bottom);
            return insets;
        });

        int[] conteo = getIntent().getIntArrayExtra("CONTEO");
        int abst = getIntent().getIntExtra("ABST", 0);
        int total = getIntent().getIntExtra("TOTAL", 0);

        tvTotal = findViewById(R.id.tvTotal);
        l1 = findViewById(R.id.tvOpt1Label);
        v1 = findViewById(R.id.tvOpt1Value);
        l2 = findViewById(R.id.tvOpt2Label);
        v2 = findViewById(R.id.tvOpt2Value);
        l3 = findViewById(R.id.tvOpt3Label);
        v3 = findViewById(R.id.tvOpt3Value);
        l4 = findViewById(R.id.tvOpt4Label);
        v4 = findViewById(R.id.tvOpt4Value);
        labst = findViewById(R.id.tvAbstLabel);
        vabst = findViewById(R.id.tvAbstValue);

        String[] opciones = getResources().getStringArray(R.array.opciones_voto);
        if (opciones.length >= 5) {
            l1.setText(opciones[1]);
            l2.setText(opciones[2]);
            l3.setText(opciones[3]);
            l4.setText(opciones[4]);
        }

        tvTotal.setText(getString(R.string.formato_total, total));

        int c1 = (conteo != null && conteo.length > 0) ? conteo[0] : 0;
        int c2 = (conteo != null && conteo.length > 1) ? conteo[1] : 0;
        int c3 = (conteo != null && conteo.length > 2) ? conteo[2] : 0;
        int c4 = (conteo != null && conteo.length > 3) ? conteo[3] : 0;

        v1.setText(formatea(c1, total));
        v2.setText(formatea(c2, total));
        v3.setText(formatea(c3, total));
        v4.setText(formatea(c4, total));
        labst.setText(getString(R.string.abstenciones));
        vabst.setText(formatea(abst, total));

        findViewById(R.id.btnReiniciar).setOnClickListener(v -> {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            finish();
        });
    }

    String formatea(int count, int total) {
        if (total <= 0) return getString(R.string.formato_conteo_porcentaje, count, 0f);
        float p = (count * 100f) / total;
        return String.format(Locale.getDefault(),
                getString(R.string.formato_conteo_porcentaje), count, p);
    }
}
