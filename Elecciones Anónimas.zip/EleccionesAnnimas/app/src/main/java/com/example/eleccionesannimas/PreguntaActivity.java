package com.example.eleccionesannimas;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PreguntaActivity extends AppCompatActivity {

    int total;
    int actual = 0;
    int abstenciones = 0;
    int[] conteo = new int[4];

    Spinner sp;
    TextView tv;
    View btnEnviar, btnAbstenerse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pregunta);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets sb = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(sb.left, sb.top, sb.right, sb.bottom);
            return insets;
        });

        total = getIntent().getIntExtra(MainActivity.EXTRA_NUM, 0);

        sp = findViewById(R.id.spRespuesta);
        tv = findViewById(R.id.tvProgreso);
        btnEnviar = findViewById(R.id.btnEnviar);
        btnAbstenerse = findViewById(R.id.btnAbstenerse);

        ArrayAdapter<CharSequence> adapter =
                ArrayAdapter.createFromResource(this, R.array.opciones_voto, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(adapter);
        sp.setSelection(0, false);

        tv.setText(getString(R.string.formato_progreso, 1, total));

        btnEnviar.setOnClickListener(v -> {
            int pos = sp.getSelectedItemPosition();
            if (pos == 0) {
                Toast.makeText(this, getString(R.string.selecciona_una_opcion), Toast.LENGTH_SHORT).show();
                return;
            }
            conteo[pos - 1]++;
            avanzar();
        });

        btnAbstenerse.setOnClickListener(v -> {
            abstenciones++;
            avanzar();
        });
    }

    void avanzar() {
        actual++;
        if (actual >= total) {
            Intent i = new Intent(this, ResultadoActivity.class);
            i.putExtra("CONTEO", conteo);
            i.putExtra("ABST", abstenciones);
            i.putExtra("TOTAL", total);
            startActivity(i);
            finish();
        } else {
            tv.setText(getString(R.string.formato_progreso, (actual + 1), total));
            sp.setSelection(0, false);
        }
    }
}
