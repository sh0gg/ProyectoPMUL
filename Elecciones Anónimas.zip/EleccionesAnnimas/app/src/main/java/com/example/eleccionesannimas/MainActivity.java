package com.example.eleccionesannimas;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_NUM = "NUM_ENCUESTADOS";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        final EditText et = findViewById(R.id.etNumeroEncuestados);
        final View btn = findViewById(R.id.bSubmit);

        btn.setOnClickListener(v -> {
            String raw = et.getText().toString().trim();
            if (raw.isEmpty()) {
                et.setError(getString(R.string.introduce_un_numero));
                return;
            }
            int participantes;
            try {
                participantes = Integer.parseInt(raw);
            } catch (NumberFormatException e) {
                et.setError(getString(R.string.numero_invalido));
                return;
            }
            if (participantes <= 2) {
                Toast.makeText(this, getString(R.string.no_hay_suficientes_participantes), Toast.LENGTH_SHORT).show();
                return;
            }

            Intent i = new Intent(MainActivity.this, PreguntaActivity.class);
            i.putExtra(EXTRA_NUM, participantes);
            startActivity(i);
        });
    }
}
